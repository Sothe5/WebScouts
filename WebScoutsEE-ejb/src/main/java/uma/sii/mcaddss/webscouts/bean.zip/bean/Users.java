/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package uma.sii.mcaddss.webscouts.bean;

import java.security.acl.Group;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import uma.sii.mcaddss.webscouts.entities.Document;
import uma.sii.mcaddss.webscouts.entities.Event;
import uma.sii.mcaddss.webscouts.entities.User_Scout;

/**
 *
 * @author Nexel
 */
@Stateless
public class Users implements UsersLocal {
    
    @PersistenceContext(unitName = "WebScoutsEEPU")
    private EntityManager em;

    @Override
    public List<User_Scout> getAllUsers() {
        Query query = em.createQuery("SELECT u FROM User_Scout u", Document.class);
        return query.getResultList();
    }

    @Override
    public List<User_Scout> getAllUsersEvent(Event event) {
        Query query = em.createQuery("SELECT u FROM User_Scout u WHERE u.events.contains(event)", Document.class);
        return query.getResultList();    
    }

    @Override
    public List<User_Scout> getAllUsersGroup(Group group) {
        Query query = em.createQuery("SELECT u FROM User_Scout u WHERE u.group = group", Document.class);
        return query.getResultList();
    }

    // Add business logic below. (Right-click in editor and choose
    // "Insert Code > Add Business Method")

    @Override
    public void addUser(User_Scout user) {
        em.persist(user);
    }
}
