/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package uma.sii.mcaddss.webscouts.bean;

import java.util.List;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import uma.sii.mcaddss.webscouts.authentication.PrivilegesControl;
import uma.sii.mcaddss.webscouts.entities.Document;
import uma.sii.mcaddss.webscouts.entities.User_Scout;

/**
 *
 * @author Nexel
 */
@Stateless
public class Document_Management implements Document_ManagementLocal {
    
    @Inject
    private PrivilegesControl priv_control;
    
    @PersistenceContext(unitName = "WebScoutsEEPU")
    private EntityManager em;

    @Override
    public void addDocument(Document doc) {
        doc.setOwner(priv_control.getUserScout());
        em.persist(doc);
    }

    @Override
    public void changeDocumentStatus(Document doc) {
        doc.setStatus(!doc.getStatus());
        em.merge(doc);
    }

    @Override
    public List<Document> getAllDocuments() {
        Query query = em.createQuery("SELECT d FROM Document d WHERE d.owner = user", Document.class);
        return query.getResultList();
    }

    @Override
    public List<Document> getDocuments(User_Scout user, boolean status) {
        Query query = em.createQuery("SELECT d FROM Document d WHERE d.owner = user AND d.status = status", Document.class);
        return query.getResultList();
    }

    @Override
    public List<Document> getAllDocumentsUser(User_Scout user) {
        Query query = em.createQuery("SELECT d FROM Document d WHERE d.owner = user", Document.class);
        return query.getResultList();
    }

    // Add business logic below. (Right-click in editor and choose
    // "Insert Code > Add Business Method")
}
